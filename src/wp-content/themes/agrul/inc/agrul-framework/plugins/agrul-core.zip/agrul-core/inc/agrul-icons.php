<?php

// Flat icons
function agrul_flaticons() {
    return [

'flaticon-sprout'=>'flaticon-sprout',

'flaticon-tractor'=>'flaticon-tractor',

'flaticon-agriculture'=>'flaticon-agriculture',

'flaticon-agriculture-1'=>'flaticon-agriculture-1',

'flaticon-tractor-1'=>'flaticon-tractor-1',

'flaticon-vegetation'=>'flaticon-vegetation',

'flaticon-farming-and-gardening'=>'flaticon-farming-and-gardening',

'flaticon-growth'=>'flaticon-growth',

'flaticon-fertilizer'=>'flaticon-fertilizer',

'flaticon-harvest'=>'flaticon-harvest',

'flaticon-planting'=>'flaticon-planting',

'flaticon-tractor-2'=>'flaticon-tractor-2',

'flaticon-tractor-3'=>'flaticon-tractor-3',

'flaticon-seed-bag'=>'flaticon-seed-bag',

'flaticon-sprayer'=>'flaticon-sprayer',

'flaticon-field'=>'flaticon-field',

'flaticon-chemicals'=>'flaticon-chemicals',

'flaticon-planting-1'=>'flaticon-planting-1',

'flaticon-tractor-4'=>'flaticon-tractor-4',

'flaticon-farmer'=>'flaticon-farmer',

'flaticon-vegetables'=>'flaticon-vegetables',

'flaticon-growing-plant'=>'flaticon-growing-plant',

'flaticon-cow'=>'flaticon-cow',

'flaticon-crop'=>'flaticon-crop',

'flaticon-leaf'=>'flaticon-leaf',

'flaticon-duck'=>'flaticon-duck',

'flaticon-field-1'=>'flaticon-field-1',

'flaticon-silo'=>'flaticon-silo',

'flaticon-drone'=>'flaticon-drone',

'flaticon-plant'=>'flaticon-plant',

'flaticon-smart-farm'=>'flaticon-smart-farm',

'flaticon-tractor-5'=>'flaticon-tractor-5',

'flaticon-product'=>'flaticon-product',

'flaticon-sprout-1'=>'flaticon-sprout-1',

'flaticon-promotion'=>'flaticon-promotion',

'flaticon-wheelbarrow'=>'flaticon-wheelbarrow',

'flaticon-planet-earth'=>'flaticon-planet-earth',

'flaticon-pesticide'=>'flaticon-pesticide',

'flaticon-wheat'=>'flaticon-wheat',

'flaticon-garden'=>'flaticon-garden',

'flaticon-weigh-scale'=>'flaticon-weigh-scale',

'flaticon-tractor-6'=>'flaticon-tractor-6',

'flaticon-greenhouse'=>'flaticon-greenhouse',

'flaticon-raining'=>'flaticon-raining',

'flaticon-pumpkins'=>'flaticon-pumpkins',

'flaticon-farmer-1'=>'flaticon-farmer-1',

'flaticon-farmhouse'=>'flaticon-farmhouse',

'flaticon-corn'=>'flaticon-corn',

'flaticon-seeds'=>'flaticon-seeds',

'flaticon-gardening-tools'=>'flaticon-gardening-tools',

'flaticon-shallot'=>'flaticon-shallot',

'flaticon-carrot'=>'flaticon-carrot',

'flaticon-tractor-7'=>'flaticon-tractor-7',

'flaticon-broccoli'=>'flaticon-broccoli',

'flaticon-corn-1'=>'flaticon-corn-1',

'flaticon-production'=>'flaticon-production',

'flaticon-rice'=>'flaticon-rice',

'flaticon-silo-1'=>'flaticon-silo-1',

'flaticon-chain-saw'=>'flaticon-chain-saw',

'flaticon-cow-1'=>'flaticon-cow-1',

'flaticon-food'=>'flaticon-food',

'flaticon-wind-farm'=>'flaticon-wind-farm',

'flaticon-farm'=>'flaticon-farm',

'flaticon-cow-2'=>'flaticon-cow-2',

'flaticon-house'=>'flaticon-house',

'flaticon-field-2'=>'flaticon-field-2',

'flaticon-farming-tools'=>'flaticon-farming-tools',

'flaticon-farmer-2'=>'flaticon-farmer-2',

'flaticon-farm-1'=>'flaticon-farm-1',

'flaticon-turbine'=>'flaticon-turbine',

'flaticon-cattle'=>'flaticon-cattle',

'flaticon-wind-far-1'=>'flaticon-wind-far-1',

'flaticon-poultry'=>'flaticon-poultry',

'flaticon-cow-3'=>'flaticon-cow-3',

'flaticon-tank'=>'flaticon-tank',

'flaticon-farmer-3'=>'flaticon-farmer-3',

'flaticon-duck-1'=>'flaticon-duck-1',

'flaticon-solar-panel'=>'flaticon-solar-panel',

'flaticon-sheep'=>'flaticon-sheep',

'flaticon-rooster'=>'flaticon-rooster',

'flaticon-dairy-products'=>'flaticon-dairy-products',

'flaticon-tractor-8'=>'flaticon-tractor-8',

'flaticon-tools'=>'flaticon-tools',

'flaticon-tank-1'=>'flaticon-tank-1',

'flaticon-support'=>'flaticon-support',

'flaticon-solar-panel-1'=>'flaticon-solar-panel-1',

'flaticon-rice-1'=>'flaticon-rice-1',

'flaticon-silo-2'=>'flaticon-silo-2',

'flaticon-farm-products'=>'flaticon-farm-products',

'flaticon-dog'=>'flaticon-dog',

'flaticon-animal'=>'flaticon-animal',

'flaticon-smart-farm-1'=>'flaticon-smart-farm-1',

'flaticon-farming'=>'flaticon-farming',

'flaticon-farmer-4'=>'flaticon-farmer-4',

'flaticon-farm-2'=>'flaticon-farm-2',

'flaticon-bee'=>'flaticon-bee',

'flaticon-house-1'=>'flaticon-house-1',

'flaticon-sheep-1'=>'flaticon-sheep-1',

'flaticon-water-well'=>'flaticon-water-well',

'flaticon-farm-house'=>'flaticon-farm-house',

'flaticon-beehive'=>'flaticon-beehive',

'flaticon-pig'=>'flaticon-pig',

'flaticon-farm-products-1'=>'flaticon-farm-products-1',

'flaticon-milk'=>'flaticon-milk',

'flaticon-bees'=>'flaticon-bees',

'flaticon-smart-farm-2'=>'flaticon-smart-farm-2',

'flaticon-windmill'=>'flaticon-windmill',

'flaticon-restaurant'=>'flaticon-restaurant',

'flaticon-salad'=>'flaticon-salad',

'flaticon-fast-food'=>'flaticon-fast-food',

'flaticon-fruit'=>'flaticon-fruit',

'flaticon-vegetable'=>'flaticon-vegetable',

'flaticon-salad-1'=>'flaticon-salad-1',

'flaticon-vegetable-1'=>'flaticon-vegetable-1',

'flaticon-healthy-food'=>'flaticon-healthy-food',

'flaticon-broccoli-1'=>'flaticon-broccoli-1',

'flaticon-broccoli-2'=>'flaticon-broccoli-2',

'flaticon-vegetables-1'=>'flaticon-vegetables-1',

'flaticon-tomato'=>'flaticon-tomato',

'flaticon-cabbage'=>'flaticon-cabbage',

'flaticon-salad-2'=>'flaticon-salad-2',

'flaticon-peas'=>'flaticon-peas',

'flaticon-colander'=>'flaticon-colander',

'flaticon-vegetable-oil'=>'flaticon-vegetable-oil',

'flaticon-onion'=>'flaticon-onion',

'flaticon-grape'=>'flaticon-grape',

'flaticon-garlic'=>'flaticon-garlic',

'flaticon-cabbage-1'=>'flaticon-cabbage-1',

'flaticon-vegetables-2'=>'flaticon-vegetables-2',

'flaticon-tomato-1'=>'flaticon-tomato-1',

'flaticon-lettuce'=>'flaticon-lettuce',

'flaticon-potato'=>'flaticon-potato',

'flaticon-boiled-egg'=>'flaticon-boiled-egg',

'flaticon-bell-pepper'=>'flaticon-bell-pepper',

'flaticon-grain'=>'flaticon-grain',

'flaticon-mortar'=>'flaticon-mortar',

'flaticon-honey'=>'flaticon-honey',

'flaticon-honey-1'=>'flaticon-honey-1',

'flaticon-honeycomb'=>'flaticon-honeycomb',

'flaticon-apitherapy'=>'flaticon-apitherapy',

'flaticon-apple'=>'flaticon-apple',

'flaticon-dairy-products-1'=>'flaticon-dairy-products-1',

'flaticon-milk-1'=>'flaticon-milk-1',

'flaticon-sausages'=>'flaticon-sausages',

'flaticon-sour-cream'=>'flaticon-sour-cream',

'flaticon-milk-tank'=>'flaticon-milk-tank',


];

}

function agrul_include_flaticons() {
    return array_keys(agrul_flaticons());
}
?>