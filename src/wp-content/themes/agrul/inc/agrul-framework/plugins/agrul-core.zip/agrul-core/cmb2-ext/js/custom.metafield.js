window.CMB2 = (function (window, document, $, undefined) {
    'use strict';

    // Switcher
    $.switcher('input.exopress-swtich');

})(window, document, jQuery);