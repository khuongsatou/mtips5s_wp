<?php
/*
Package: Vlogger
*/
?>
<!-- PAGINATION ========================= -->
<div class="qt-pagination qt-content-primary qt-negative">
	<ul class="pagination qt-container">
 		<?php vlogger_page_navi($wp_query); ?>
	</ul>
</div>
<!-- PAGINATION END ========================= -->
