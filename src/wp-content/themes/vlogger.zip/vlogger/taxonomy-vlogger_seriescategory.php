<?php  
get_template_part('archive-vlogger_serie' );
?>