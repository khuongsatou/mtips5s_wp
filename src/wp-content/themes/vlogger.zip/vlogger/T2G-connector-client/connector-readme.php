

=================================
CONNECTOR THEME DASHBOARD PLUGIN
=================================

This plugin creates an easy-to-use dashboard to manage updates and demo contents
